module.exports = function (req) {
  req.query = {}
}
