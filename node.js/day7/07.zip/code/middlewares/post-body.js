module.exports = function (req, res) {
  req.body = {}
}
